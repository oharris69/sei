SEI demo site - asset pack (2026-11-04)
Site: https://main--sei--oharris69.aem.live/   Document Authoring (DA): oharris69/sei

CONTENTS
- images       Every image the pages use, in the same folders as in DA (images/<page>/...).
               Logos: images/logos (client logos, colour and white versions) and
               images/shared (SEI logo, footer logo, UI images).
- icons        The SVG icons used by the site's blocks and styles.
- favicon.ico
- brand-graphics/terrazzo-tile.svg   The pattern used by the "Lobby Floor" rebrand page.
- manifest.csv One row per file: type, size in pixels, file size, the pages that use it,
               and its DA URL.

NOT INCLUDED
- PDFs and other documents: the site has none. The Pathfinder "Buyer's Guide" link
  points to a PDF that does not exist yet.
- Fonts: CircularXX is SEI's licensed brand font and is kept out of this pack.
  Archivo and Source Serif 4 (free, OFL) are in the site's fonts folder.
- Videos: the Summit Wealth video streams from SEI's Brightcove account. See
  sei-video-request.md (in the project's reference folder) for the MP4 request list.

IMAGE SOURCES
Exports from the Figma file "DXP-Demo-Final" (some hero backgrounds rebuilt from the Figma
renders), plus two images from seic.com for the Summit Wealth story page
(images/summit-wealth).
